Compilation: 
- I was able to compile my program in the virtual box with defaults (Mounted folder into VM and used the premake4/make combination within the CS488 and then A0 directories) 

Manual: 
- Added a function for resetting the triangle (added declaration to hpp file) which is called on button click/<R> key press