// Termm--Fall 2020

#include "Material.hpp"

Material::Material()
{}

Material::~Material()
{}
