// Termm-Fall 2020

#pragma once

#include <string>
#include "SceneNode.hpp"

SceneNode * import_lua(const std::string & filename);

